cd frontend && npm install && npm run build
cd ../backend && mvn clean install
./mvnw spring-boot:run
